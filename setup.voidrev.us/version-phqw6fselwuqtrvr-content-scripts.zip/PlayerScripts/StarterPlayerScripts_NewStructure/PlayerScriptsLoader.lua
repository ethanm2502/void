--[[
	PlayerScriptsLoader - This script requires and instantiates the PlayerModule singleton
	
	2018 PlayerScripts Update - AllYourBlox	
--]]
local PlayerModule = require(script.Parent:WaitForChild("PlayerModule"))