local CorePackages = game:GetService("CorePackages")

local initify = require(CorePackages.initify)

initify(CorePackages.TestEZImpl)

return require(CorePackages.TestEZImpl)