local CorePackages = game:GetService("CorePackages")

local initify = require(CorePackages.initify)

initify(CorePackages.RoactImpl)

return require(CorePackages.RoactImpl)