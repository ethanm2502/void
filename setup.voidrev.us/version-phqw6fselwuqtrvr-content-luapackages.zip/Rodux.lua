local CorePackages = game:GetService("CorePackages")

local initify = require(CorePackages.initify)

initify(CorePackages.RoduxImpl)

return require(CorePackages.RoduxImpl)