return function()
	itFIXME("should load successfully", function()
		require(script.Parent)
	end)
end