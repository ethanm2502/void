return {
	createGroupMotor = require(script.createGroupMotor),
	createSingleMotor = require(script.createSingleMotor),
	spring = require(script.spring),
	instant = require(script.instant),
}