local Symbol = require(script.Parent.Symbol)

return Symbol.named("RoduxStore")