local Scroller = require(script.Components.Scroller)

return {
	Scroller = Scroller,
}
