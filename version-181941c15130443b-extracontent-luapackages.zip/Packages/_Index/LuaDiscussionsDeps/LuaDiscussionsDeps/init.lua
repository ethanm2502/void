local LuaDiscussionsDeps = script.Parent

return {
	InfiniteScroll = require(LuaDiscussionsDeps.InfiniteScroll),
	RoactFitComponents = require(LuaDiscussionsDeps.RoactFitComponents),
	RoactNavigation = require(LuaDiscussionsDeps.RoactNavigation),
	RoduxNetworking = require(LuaDiscussionsDeps.RoduxNetworking),
}
