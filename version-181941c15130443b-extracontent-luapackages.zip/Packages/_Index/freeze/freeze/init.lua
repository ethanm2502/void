return {
	List = require(script.List.List),
	sort = require(script.sort.sort),
	OrderedMap = require(script.OrderedMap.OrderedMap),
	OrderedSet = require(script.OrderedSet.OrderedSet),
	UnorderedMap = require(script.UnorderedMap.UnorderedMap),
	UnorderedSet = require(script.UnorderedSet.UnorderedSet),
	deepJoin = require(script.deepJoin.deepJoin),
	None = require(script.None),
}