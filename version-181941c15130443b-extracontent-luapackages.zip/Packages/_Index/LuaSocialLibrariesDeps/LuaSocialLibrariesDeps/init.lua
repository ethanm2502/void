local LuaSocialLibrariesDeps = script.Parent

return {
	GenericPagination = require(LuaSocialLibrariesDeps.GenericPagination),
	RoactFitComponents = require(LuaSocialLibrariesDeps.RoactFitComponents),
	Mock = require(LuaSocialLibrariesDeps.Mock),
}
