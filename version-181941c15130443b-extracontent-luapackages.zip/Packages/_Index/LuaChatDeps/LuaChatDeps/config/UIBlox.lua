return {
	fixToastResizeConfig = true,
	expandableTextAutomaticResizeConfig = true,
}
