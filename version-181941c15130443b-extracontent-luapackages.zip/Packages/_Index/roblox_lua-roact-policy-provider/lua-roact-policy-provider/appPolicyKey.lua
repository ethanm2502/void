local Packages = script.Parent.Parent
local Symbol = require(Packages.Symbol)

return Symbol.named("AppPolicy")
