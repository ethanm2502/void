-- Generator information:
-- Human name: GenericPagination
-- Variable name: GenericPagination
-- Repo name: genericpagination

local Paginator = require(script.Paginator)

return Paginator