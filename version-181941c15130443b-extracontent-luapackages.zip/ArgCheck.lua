local CorePackages = game:GetService("CorePackages")

local initify = require(CorePackages.initify)

initify(CorePackages.ArgCheckImpl)

return require(CorePackages.ArgCheckImpl)