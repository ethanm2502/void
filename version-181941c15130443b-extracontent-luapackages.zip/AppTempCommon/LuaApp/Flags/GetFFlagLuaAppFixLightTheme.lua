game:DefineFastFlag("LuaAppFixLightTheme", false)

return function()
	return game:GetFastFlag("LuaAppFixLightTheme")
end