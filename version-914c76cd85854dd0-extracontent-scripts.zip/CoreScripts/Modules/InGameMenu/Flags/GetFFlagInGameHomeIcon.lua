game:DefineFastFlag("InGameHomeIcon", false)

return function()
	return game:GetFastFlag("InGameHomeIcon")
end