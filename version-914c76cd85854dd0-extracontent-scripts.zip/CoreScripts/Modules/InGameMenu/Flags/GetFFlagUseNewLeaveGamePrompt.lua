game:DefineFastFlag("UseNewLeaveGamePrompt", false)

return function()
	return game:GetFastFlag("UseNewLeaveGamePrompt")
end
