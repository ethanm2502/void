-- This needs to be a static flag because the uses of the flag is static
-- 	dynamically changing this value will cause a crash
return game:DefineFastFlag("FixInGameNavTreeCrash", false)
