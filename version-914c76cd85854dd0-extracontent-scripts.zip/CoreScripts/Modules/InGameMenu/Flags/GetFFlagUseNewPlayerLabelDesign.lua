game:DefineFastFlag("UseNewPlayerLabelDesign2", false)
return function()
	return game:GetFastFlag("UseNewPlayerLabelDesign2")
end