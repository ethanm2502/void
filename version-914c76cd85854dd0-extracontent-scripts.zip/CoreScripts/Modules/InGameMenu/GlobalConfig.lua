local GlobalConfig = {
	propValidation = false,
	elementTracing = false,
	logStore = false,
}

return GlobalConfig