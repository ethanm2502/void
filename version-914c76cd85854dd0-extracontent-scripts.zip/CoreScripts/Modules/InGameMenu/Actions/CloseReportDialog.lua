local CorePackages = game:GetService("CorePackages")

local Action = require(CorePackages.AppTempCommon.Common.Action)

return Action("CLOSE_REPORT_DIALOG", function()
	return {}
end)