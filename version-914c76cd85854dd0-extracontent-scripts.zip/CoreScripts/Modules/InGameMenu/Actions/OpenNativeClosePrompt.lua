local CorePackages = game:GetService("CorePackages")

local Action = require(CorePackages.AppTempCommon.Common.Action)

return Action("OPEN_NATIVE_CLOSE_PROMPT", function()
	return {}
end)
