return function()
	local CorePackages = game:GetService("CorePackages")
	local Roact = require(CorePackages.Roact)
	local RoactRodux = require(CorePackages.RoactRodux)
	local Store = require(CorePackages.Rodux).Store

	local CircularBuffer = require(script.Parent.Parent.Parent.CircularBuffer)

	local DataProvider = require(script.Parent.Parent.DataProvider)
	local ServerScriptsEntry = require(script.Parent.ServerScriptsEntry)

	it("should create and destroy without errors", function()
		local dummyScriptEntry = {
			time = 0,
			data = {0, 0},
		}
		local dataSet = CircularBuffer.new(1)
		dataSet:push_back(dummyScriptEntry)

		local formatScriptsData = function()
			return ""
		end

		local scriptDummyData = {
			dataStats = {
				min = 0,
				max = 0,
				dataSet = dataSet,
			}
		}

		local dummyCellSizes = {
			UDim2.new(),
			UDim2.new(),
			UDim2.new(),
		}

		local store = Store.new(function()
			return {
				MainView = {
					isDeveloperView = true,
				},
			}
		end)

		local element = Roact.createElement(RoactRodux.StoreProvider, {
			store = store,
		}, {
			DataProvider = Roact.createElement(DataProvider, {}, {
				ServerScriptsEntry = Roact.createElement(ServerScriptsEntry, {
					scriptData = scriptDummyData,
					entryCellSize = dummyCellSizes,
					cellOffset = dummyCellSizes,
					verticalOffsets = dummyCellSizes,
					formatScriptsData = formatScriptsData,
				})
			})
		})

		local instance = Roact.mount(element)
		Roact.unmount(instance)
	end)
end