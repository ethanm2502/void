return {
	-- Whether or not to run assertions on arguments to action creators. Since
	-- the actions can get called a ton in large servers with players chatting
	-- constantly, this is useful to save a bit of performance.
	actionValidation = false,
}
