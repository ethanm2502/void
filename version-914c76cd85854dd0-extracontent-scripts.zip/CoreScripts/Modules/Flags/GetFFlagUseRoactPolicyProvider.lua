game:DefineFastFlag("UseRoactPolicyProvider", false)

return function()
	return game:GetFastFlag("UseRoactPolicyProvider")
end
