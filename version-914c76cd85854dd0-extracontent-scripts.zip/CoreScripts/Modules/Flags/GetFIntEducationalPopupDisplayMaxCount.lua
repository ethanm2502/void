game:DefineFastInt("EducationalPopupDisplayMaxCount", 1)
return function()
	return game:GetFastInt("EducationalPopupDisplayMaxCount")
end
