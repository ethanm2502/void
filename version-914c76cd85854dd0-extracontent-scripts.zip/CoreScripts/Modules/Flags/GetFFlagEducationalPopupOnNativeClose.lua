game:DefineFastFlag("EducationalPopupOnNativeClose", false)

return function()
	return game:GetFastFlag("EducationalPopupOnNativeClose")
end
