game:DefineFastFlag("InstrumentMenuOpenMethods", false)

return function()
	return game:GetFastFlag("InstrumentMenuOpenMethods")
end
