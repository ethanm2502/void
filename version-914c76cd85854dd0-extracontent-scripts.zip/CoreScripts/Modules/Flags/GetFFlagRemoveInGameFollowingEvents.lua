game:DefineFastFlag("RemoveInGameFollowingEvents", false)

return function()
	return game:GetFastFlag("RemoveInGameFollowingEvents")
end
