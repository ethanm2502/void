game:DefineFastFlag("AppUsesAutomaticQualityLevel", false)

return function()
	return game:GetFastFlag("AppUsesAutomaticQualityLevel")
end