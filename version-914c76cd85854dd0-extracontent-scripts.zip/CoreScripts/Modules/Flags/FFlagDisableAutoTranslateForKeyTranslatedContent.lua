return game:DefineFastFlag("DisableAutoTranslateForKeyTranslatedContent", false)
