game:DefineFastFlag("LuaPremiumCatalogIGIAB", false)

return function()
	return game:GetFastFlag("LuaPremiumCatalogIGIAB")
end