game:DefineFastFlag("FullscreenAnalytics", false)

return function()
    return game:GetFastFlag("FullscreenAnalytics")
end
